<?php
/**
 * @package   T3 Blank
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
?>

<div class="home">

  <?php if ($this->countModules('home-2')) : ?>
  <!-- HOME SL 2 -->
  <div class="container t3-sl t3-sl-2<?php $this->_c('home-2')?>">
    <jdoc:include type="modules" name="<?php $this->_p('home-2') ?>" style="raw" />
  </div>
  <!-- //HOME SL 2 -->
  <?php endif ?>

</div>
